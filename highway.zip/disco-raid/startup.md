How to setup:

1. Firstly, create a discord bot at https://discord.com/developers/applications
2. open 'example.env' and fill the information
3. rename example.env to .env
4. make sure NodeJS is installed
5. run 'npm install' 
6. run 'npm install nodemon'
7. go inside the 'source' directory and run 'node register.js'
8. finally oustide of the 'source' directory run 'npm start'